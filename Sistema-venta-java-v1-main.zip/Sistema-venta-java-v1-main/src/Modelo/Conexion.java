package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

     public static final String URL = "jdbc:mysql://localhost:3306/registro";
    public static final String USER = "root";
    public static final String CLAVE = "";

    Connection con;

    public Connection getConnection() {
        try {
            String myBD = "com.mysql.cj.jdbc.Driver";
            con = DriverManager.getConnection(URL, USER, CLAVE);
            return con;
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return null;
    }

}
